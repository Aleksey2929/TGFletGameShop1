import flet as ft
from pages.storage import state_manager

def home_page(page: ft.Page):

    products = [
        {"name": "BrawlStars", "price": 10.99, "image": 'https://play-lh.googleusercontent.com/oySYfm7jpqxH6J03yKXYU69SmV2BcJ92Wa9BWPUnGXI8NFW1u5aKik3SY3Is7INsf4U', 'description':'Информация будет добавлена позже'},
        {"name": "Fornite", "price": 10.99, "image": 'https://habrastorage.org/getpro/habr/upload_files/d68/2b9/707/d682b9707704038213d18f3447184a62.png', 'description':'Информация будет добавлена позже'},
        {"name": "FC Mobile", "price": 10.99, "image": 'https://play-lh.googleusercontent.com/Jy_gJvivP98Xve8lhhk_eM2MJ68XdIQFN6UQnZIrbn_64C5Hnl48OQKgR_gVlEOk2sJP', 'description':'Информация будет добавлена позже'},
        {"name": "World of Tanks: Blitz", "price": 10.99, "image": 'https://gaming-cdn.com/images/products/1943/616x353/world-of-tanks-pc-mac-game-cover.jpg?v=1706195982', 'description':'Информация будет добавлена позже'},
    ]

    def see_more(e, product):
        state_manager.curent_product = product
        page.go('/details')

    product_cards = []
    for p in products:
        card = ft.Card(
            content=ft.Column(
                [
                    ft.Image(src=p['image'], width=360, height=150),
                    ft.Text(p['name'], size=18, weight='bold'),
                    ft.Row(
                        [
                            ft.ElevatedButton('Details', bgcolor='red', on_click=lambda e, product=p: see_more(e,product)),
                            ft.Text(f"Price: {p['price']} $", size=16),
                        ],
                        alignment=ft.MainAxisAlignment.CENTER
                    )
                ],
                alignment=ft.MainAxisAlignment.START,
                horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                spacing=10
            ),
            width=360,
            height=200
        )
        product_cards.append(card)

    # Используем GridView для отображения карточек
    return ft.GridView(
        controls=product_cards,
        expand=1,
        runs_count=5,
        max_extent=360,
        child_aspect_ratio=1.0,
        spacing=5,
        run_spacing=5,
    )
