import flet as ft
from pages.storage import state_manager

def details_page(page: ft.Page, product):
    dlg = ft.AlertDialog(
        title=ft.Text("Alert"),
        content=ft.Text("Good has been adeed in cart!"),
        alignment=ft.alignment.center,
        on_dismiss=lambda e: print("Dialog dismissed!"),
        title_padding=ft.padding.all(25),
        actions=[
            ft.TextButton("Done", on_click=lambda e: page.close(dlg)),
        ],
    )

    def go_back(e):
        page.go('/home')
    def bye(e):

        if not hasattr(state_manager, 'cart'):
            state_manager.cart = []
            state_manager.cart = product
        else:
            state_manager.cart = product
        print('Вы добавили следующий товар:\n', product)
        page.open(dlg)

    return ft.Column(
        [
            ft.Image(src=product['image'], width=320, height=150),
            ft.Text(product['name'], size=24, weight='bold'),
            ft.Text('Тут будет блинное описание', size=20, weight='bold'),
            ft.Row(
                [
                    ft.Text(f"Price: {product['price']} $", size=20),
                    ft.ElevatedButton("Bye", on_click=bye),
                ],
                alignment=ft.MainAxisAlignment.CENTER,
            ),
            ft.ElevatedButton("Back", on_click=go_back),
        ],
        alignment=ft.MainAxisAlignment.CENTER,
        horizontal_alignment=ft.CrossAxisAlignment.CENTER,
        spacing=20,
        scroll=ft.ScrollMode.ALWAYS
        )
