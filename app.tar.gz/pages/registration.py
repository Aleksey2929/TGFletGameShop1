import flet as ft

def signup_page(page: ft.Page):
    error_text = ft.Text('', color='red')
     # Form controls
    login = ft.TextField(label="Username", width=300)
    password = ft.TextField(label="Password", password=True, width=300)
    confirm_password = ft.TextField(label="Password", password=True, width=300)

    def registration_click(e):
        # TODO тут будет логика регистрации
        page.go('/')
    def go_to_login(e):
        # TODO тут будет логика авторизации
        page.go('/')

    return ft.Column(
        [
            ft.Text('Registration', size=24),
            login,
            password,
            confirm_password,
            ft.ElevatedButton('Sign up', on_click=registration_click, width=300),
            ft.TextButton("Already have an accont? Sign in",  on_click=go_to_login),
            error_text
        ],
        alignment=ft.MainAxisAlignment.CENTER,
        horizontal_alignment=ft.CrossAxisAlignment.CENTER,
        spacing=20
    )
